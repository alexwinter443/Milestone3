<!doctype html>
<html lang="<?php echo e(str_replace('_', '_', app()->getLocale())); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content-width=device-width, initial-scale=1>
	<title>Career</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container">
	<ul class="nav">
          <li class="nav-item">
            <a class="nav-link href="/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about-us">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact-us">Contact Us</a>
          </li>
            <li class="nav-item">
            <a class="nav-link" href="customer">Customer</a>
          </li>
          </li>
            <li class="nav-item">
            <a class="nav-link" href="myprofile">My Profile</a>
          </li>
          <div class="container">
         	<?php echo $__env->yieldContent('content'); ?>
          </div>
          <div class="container">
         	<?php echo $__env->yieldContent('adminManagement'); ?>
          </div>
        </ul>
	</div>
</body>
</html><?php /**PATH C:\Users\Alexv\Downloads\MilestoneCLC256-main\MilestoneCLC256-main\resources\views/home.blade.php ENDPATH**/ ?>