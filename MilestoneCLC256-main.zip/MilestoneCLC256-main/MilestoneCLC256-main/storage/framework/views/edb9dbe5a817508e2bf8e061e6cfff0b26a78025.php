<?php $__env->startSection('content'); ?>
	<h1>Contact Information</h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alexv\Downloads\MilestoneCLC256-main\MilestoneCLC256-main\resources\views/contact.blade.php ENDPATH**/ ?>