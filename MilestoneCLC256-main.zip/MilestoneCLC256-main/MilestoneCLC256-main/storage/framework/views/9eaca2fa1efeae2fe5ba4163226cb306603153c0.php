<h1>About Us</h1>
<p>Company bio here...</p><?php /**PATH C:\Users\Alexv\Downloads\MilestoneCLC256-main\MilestoneCLC256-main\resources\views/about.blade.php ENDPATH**/ ?>